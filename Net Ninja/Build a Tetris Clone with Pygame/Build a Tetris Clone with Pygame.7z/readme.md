# Build Tetris with Pygame

https://www.youtube.com/playlist?list=PL4cUxeGkcC9iurLoO9Mu7GqsKlxEXcf8m

https://github.com/clear-code-projects/pygame_tetris
